<template>
    <div>{{msg}}</div>
</template>

<script>
export default {
  data(){
      return {
          msg:'hello, SSR '
      }
  },
  created(){

  }
}
</script>

<style>

</style>
