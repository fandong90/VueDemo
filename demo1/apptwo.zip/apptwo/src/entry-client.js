const { app , router } = require('./main').createApp();


router.onReady(() => {

    /**路由准备好挂载 */
    app.$mount('#app');
    
  });
