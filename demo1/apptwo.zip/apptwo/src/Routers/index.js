import Vue from 'vue';
import VueRouter from 'vue-router';
import Foo from '../Components/foo.vue';


Vue.use(VueRouter);

export function createRouter(){

    return new VueRouter({
        mode:'history',
        routes:[ { path:'/',component: Foo }]
    });
} 